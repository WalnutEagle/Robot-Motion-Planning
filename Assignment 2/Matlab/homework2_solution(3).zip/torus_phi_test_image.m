function torus_phi_test_image()
figDir='../../assignments/figures/';
torus_phi_test()
savefigure(fullfile(figDir,'torus_phi_test'),'pdf',[4,3])
%\x08

