%function sphere_testCollision()
%Generates one figure with a sphere ( xCenter=[0;0],  r=1, rInfluence=1.1) and 
%NPoints=100 random points that are colored according to the sign of their
%distance from the sphere (red for negative, green for positive). Generates a
%second figure in the same way (and the same set of points) but with 
%rInfluence=0.9.
function sphere_testCollision()
