%function clfcbf_planner_runPlotTest()
%Show the results of potential_planner_runPlot for one combination of @boxIvory2
%repulsiveWeight and @boxIvory2 epsilon that makes the planner work reliably.
function clfcbf_planner_runPlotTest()

%For the argument @boxIvory2 plannerParameters.U, use potential_attractive, for
%the argument @boxIvory2 plannerParameters.control, use @boxIvory2
%@clfcbf_control, for @boxIvory2 plannerParameters.NSteps, use @boxIvory2 20 (but
%increase to @boxIvory2 25 if necessary), and for @boxIvory2 potential.shape, use
%@boxIvory2 'quadratic'.
