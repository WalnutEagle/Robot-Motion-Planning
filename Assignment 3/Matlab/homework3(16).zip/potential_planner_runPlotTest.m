%function potential_planner_runPlotTest()
%Show the results of potential_planner_runPlot for each goal location in
%@boxIvory2 world.xGoal, and for different interesting combinations of @boxIvory2
%potential.repulsiveWeight, @boxIvory2 potential.shape, @boxIvory2
%plannerParameters.epsilon, and @boxIvory2 plannerParameters.NSteps. In each
%case, for the structure @boxIvory2 plannerParameters should have the field
%@boxIvory2 U set to @boxIvory2 @potential_total, and the field @boxIvory2
%control set to the negative of @boxIvory2 @potential_totalGrad.
function potential_planner_runPlotTest()

%For the @boxIvory2 plannerParameters.control argument, pass a function computing
%the negative of the gradient. Start with $ $ in the inteval $@boxIvory2
%0.01-@boxIvory2 0.1$, $ $ in the range $@boxIvory2 1e-3-@boxIvory2 1e-2$, for
%@boxIvory2 plannerParameters.NSteps, use @boxIvory2 100, and explore from there.
%Typically, adjustments in @boxIvory2 repulsiveWeight require subsequent
%adjustments in @boxIvory2 epsilon. For  every case where the planner converges,
%add a plot where you zoom in closely around the final equilibrium. Hints are
%available for this question.
