%function graph_search_test()
%Call graph_search to find a path between the bottom left node and the top right
%node of the @boxIvory2 graphVectorMedium graph from the
%@boxIvory2!70!DarkSeaGreen2 graph_testData.mat file (see Question~ q:graph test
%data). Then use graph_plot() to visualize the result.
function graph_search_test()
