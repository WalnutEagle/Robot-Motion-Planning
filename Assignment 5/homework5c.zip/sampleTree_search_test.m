%function sampleTree_search_test()
%enumerate  the variables @boxIvory2 world, @boxIvory2 xStart and @boxIvory2 xEnd
%from the file @boxIvory2!70!DarkSeaGreen2 sphereWorld.mat.  each starting
%location (column) in @boxIvory2 xStart, and each goal location (column) in
%@boxIvory2 xGoal, calls sampleTree_search to find a path.  sphereworld_draw and
%then overimposes all the trajectories from the start locations to the goal
%location. enumerate
function sampleTree_search_test()
