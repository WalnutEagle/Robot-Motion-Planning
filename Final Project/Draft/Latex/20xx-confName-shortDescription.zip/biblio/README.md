# Description
Collection of all biblio files for citations loosely organized by topics.

# Content
 *.bib		BibTeX files
 ieee.bst	Standard BibTeX style for IEEE

