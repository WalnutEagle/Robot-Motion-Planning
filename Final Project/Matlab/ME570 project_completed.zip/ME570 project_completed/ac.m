actions = [0 -1; 0 1; -1 0; 1 0]; % up, down, left, right
rewardObstacle = -100;
rewardGoal = 100;
rewardMove = -1;
