gridSize = 10;
numObstacles = 20;

% Initialize grid
grid = zeros(gridSize);

% Place robot (1,1) and goal (10,10)
robotPos = [1 1];
goalPos = [10 10];
grid(robotPos(1), robotPos(2)) = -1; % Robot
grid(goalPos(1), goalPos(2)) = -2; % Goal

% Place obstacles
for i = 1:numObstacles
    obstaclePos = ceil(rand(1, 2) * gridSize);
    while isequal(obstaclePos, robotPos) || isequal(obstaclePos, goalPos)
        obstaclePos = ceil(rand(1, 2) * gridSize);
    end
    grid(obstaclePos(1), obstaclePos(2)) = 1;
end
