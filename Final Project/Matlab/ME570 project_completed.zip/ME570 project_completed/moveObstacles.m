function grid = moveObstacles(grid, gridSize)
    [obstacleRows, obstacleCols] = find(grid == 1);
    numObstacles = length(obstacleRows);

    for i = 1:numObstacles
        currentPos = [obstacleRows(i), obstacleCols(i)];
        possibleMoves = [0 -1; 0 1; -1 0; 1 0]; % up, down, left, right
        move = possibleMoves(randi(4), :);
        newPos = currentPos + move;

        % Check for grid boundaries and overlap with robot (-1) or goal (-2)
        if newPos(1) >= 1 && newPos(1) <= gridSize && ...
           newPos(2) >= 1 && newPos(2) <= gridSize && ...
           grid(newPos(1), newPos(2)) <= 0
            grid(currentPos(1), currentPos(2)) = 0;
            grid(newPos(1), newPos(2)) = 1;
        end
    end
end
