% Environment setup
gridSize = 10;
numObstacles = 20;
% Initialize grid, robot, goal, and obstacles
% ...

% Q-learning parameters
alpha = 0.1; % Learning rate
gamma = 0.9; % Discount factor
epsilon = 0.1; % Exploration rate
% ...

% Q-table initialization
% ...

% Main loop
for episode = 1:maxEpisodes
    % Initialize state
    % ...
    while ~isGoalReached && stepCount < maxSteps
        % Choose action (epsilon-greedy strategy)
        % ...

        % Take action and observe new state and reward
        % ...

        % Q-table update
        % ...

        % Update state
        % ...
    end
end
