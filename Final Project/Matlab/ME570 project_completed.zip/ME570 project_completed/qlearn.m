% Q-learning parameters
alpha = 0.1; % Learning rate
gamma = 0.9; % Discount factor
epsilon = 0.1; % Exploration rate
qTable = zeros(gridSize, gridSize, 4); % 4 actions: up, down, left, right
