% ... [Previous setup code] ...

% for episode = 1:10 % Test for 10 episodes
%     grid = moveObstacles(grid, gridSize); % Move obstacles
%     stepCount = 0;
%     currentState = robotPos;
%     isGoalReached = false;
% 
%     % ... [Q-learning loop code] ...
%     maxEpisodes = 10;
%     maxSteps = 100;
% 
%     for episode = 1:maxEpisodes
%         stepCount = 0;
%         currentState = robotPos;
%         isGoalReached = false;
% 
%         while ~isGoalReached && stepCount < maxSteps
%             % Exploration or exploitation
%             if rand < epsilon
%                 action = ceil(rand * 4);
%             else
%                 [~, action] = max(qTable(currentState(1), currentState(2), :));
%             end
% 
%             % Take action
%             newState = currentState + actions(action, :);
% 
%             % Check if new state is valid
%             if newState(1) < 1 || newState(1) > gridSize || ...
%                     newState(2) < 1 || newState(2) > gridSize
%                 continue; % Skip to next iteration
%             end
% 
%             % Reward assignment
%             if isequal(newState, goalPos)
%                 reward = rewardGoal;
%                 isGoalReached = true;
%             elseif grid(newState(1), newState(2)) == 1
%                 reward = rewardObstacle;
%             else
%                 reward = rewardMove;
%             end
% 
%             % Q-table update
%             oldQValue = qTable(currentState(1), currentState(2), action);
%             maxFutureQ = max(qTable(newState(1), newState(2), :));
%             newQValue = (1 - alpha) * oldQValue + alpha * (reward + gamma * maxFutureQ);
%             qTable(currentState(1), currentState(2), action) = newQValue;
% 
%             % Update current state
%             currentState = newState;
%             stepCount = stepCount + 1;
% 
%             % % Update visualization
%             % visualizeGrid(grid, currentState, goalPos);
%             % pause(0.1); % Short pause to visualize movement
% 
%             % Check for goal reached and display message
%             if isGoalReached
%                 disp('Goal Reached!');
%                 break; % Exit the loop if goal is reached
%             end
%         end
%     end
%     % Visualization
%     disp(['Episode ', num2str(episode)]);
%     visualizeGrid(grid, robotPos, goalPos);
%     pause(1); % Pause for 1 second between episodes
% end

for episode = 1:maxEpisodes
    stepCount = 0;
    currentState = robotPos;
    isGoalReached = false;

    while ~isGoalReached && stepCount < maxSteps
        % Move obstacles at the beginning of each step
        grid = moveObstacles(grid, gridSize);

        % Exploration or exploitation
        if rand < epsilon
            action = ceil(rand * 4);
        else
            [~, action] = max(qTable(currentState(1), currentState(2), :));
        end

        % Take action
        newState = currentState + actions(action, :);

        % Check if new state is valid
        if newState(1) < 1 || newState(1) > gridSize || ...
                newState(2) < 1 || newState(2) > gridSize
            continue; % Skip to next iteration
        end

        % Reward assignment
        if isequal(newState, goalPos)
            reward = rewardGoal;
            isGoalReached = true;
        elseif grid(newState(1), newState(2)) == 1
            reward = rewardObstacle;
        else
            reward = rewardMove;
        end

        % Q-table update
        oldQValue = qTable(currentState(1), currentState(2), action);
        maxFutureQ = max(qTable(newState(1), newState(2), :));
        newQValue = (1 - alpha) * oldQValue + alpha * (reward + gamma * maxFutureQ);
        qTable(currentState(1), currentState(2), action) = newQValue;

        % Update current state
        currentState = newState;
        stepCount = stepCount + 1;

        % Update visualization
        visualizeGrid(grid, currentState, goalPos);
        pause(0.1); % Short pause to visualize movement

        % Check for goal reached and display message
        if isGoalReached
            disp('Goal Reached!');
            break; % Exit the loop if goal is reached
        end
    end

    % Visualization
    disp(['Episode ', num2str(episode)]);
    visualizeGrid(grid, robotPos, goalPos);
    pause(1); % Pause for 1 second between episodes
end
