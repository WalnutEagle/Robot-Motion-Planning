% function visualizeGrid(Environmentgrid, robotPos, goalPos)
%     gridDisplay = Environmentgrid;
%     gridDisplay(robotPos(1), robotPos(2)) = -1; % Robot
%     gridDisplay(goalPos(1), goalPos(2)) = -2; % Goal
%     imagesc(gridDisplay);
%     colormap(gray);
%     axis equal;
%     grid on;
% end

% function visualizeGrid(Environmentgrid, robotPos, goalPos)
%     clf; % Clear current figure
%     hold on; % Hold on to plot multiple elements
%     imagesc(Environmentgrid); % Display the grid
%     colormap(gray); % Set colormap
% 
%     % Plot robot
%     plot(robotPos(2), robotPos(1), 'ks', 'MarkerSize', 10, 'MarkerFaceColor', 'black'); % Black square
% 
%     % Plot goal
%     plot(goalPos(2), goalPos(1), 'g*', 'MarkerSize', 10); % Green star
% 
%     axis equal;
%     grid on;
%     hold off;
% end

function visualizeGrid(Environmentgrid, robotPos, goalPos)
    clf; % Clear current figure
    hold on; % Hold on to plot multiple elements

    % Create a grey grid background
    greyGrid = ones(size(Environmentgrid)) * 0.5; % Grey color
    imagesc(greyGrid); % Display the grey grid

    % Plot obstacles as white squares
    [obstacleRows, obstacleCols] = find(Environmentgrid == 1);
    plot(obstacleCols, obstacleRows, 'ws', 'MarkerSize', 10, 'MarkerFaceColor', 'white'); % White squares for obstacles

    % Plot robot as a black circle
    robotMarkerSize = 5; % Adjust this size as needed
    plot(robotPos(2), robotPos(1), 'ko', 'MarkerSize', robotMarkerSize, 'MarkerFaceColor', 'black'); % Black circle for robot

    % Plot goal as a green star
    plot(goalPos(2), goalPos(1), 'g*', 'MarkerSize', 10); % Green star for goal

    axis equal;
    grid on;
    hold off;
end
